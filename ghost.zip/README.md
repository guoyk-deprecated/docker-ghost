# Tuned Ghost

This Ghost is a Tuned Ghost for my personal usage [https://blog.yanke.io](https://blog.yanke.io)

Will track original releases as frequently as possible.

Current base version: 0.6.3

Docker repo: yanke/ghost:latest

# Changes

*  expose `trackId`, `disqusId` config pairs to theme.

# Roadmap

In contrast to original repo, `master` branch will always be latest release.
