# Tuned Casper

This Casper is a Tuned Casper for my personal usage [https://blog.yanke.io](https://blog.yanke.io)

Will track original releases as frequently as possible.

Current base version: 1.2.3

# Changes

*  use `@blog.trackId`, `@blog.disqusId` to render GA and Disqus

# Roadmap

In contrast to original repo, `master` branch will always be latest release.
