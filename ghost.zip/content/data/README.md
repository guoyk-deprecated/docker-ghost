# Content / Data

This is the home of your Ghost database, do not overwrite this folder or any of the files inside of it.